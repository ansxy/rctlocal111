<?php

return [

    'main_navigation'               => 'GLAVNA NAVIGACIJA',
    'blog'                          => 'Blog',
    'pages'                         => 'Strane',
    'account_settings'              => 'PODEŠAVANJA NALOGA',
    'profile'                       => 'Profil',
    'change_password'               => 'Promena lozinke',
    'multilevel'                    => 'Više nivoa',
    'level_one'                     => 'Nivo 1',
    'level_two'                     => 'Nivo 2',
    'level_three'                   => 'Nivo 3',
    'labels'                        => 'OZNAKE',
    'important'                     => 'Važno',
    'warning'                       => 'Upozorenje',
    'information'                   => 'Informacije',
    'menu'                          => 'MENI',
    'users'                         => 'Korisnici',
];
